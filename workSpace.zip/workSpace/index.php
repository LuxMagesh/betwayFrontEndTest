<!DOCTYPE html>

<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0"/>
<link rel='stylesheet' href='style/style.css'/>
<title>Random User Generator</title>

</head>
<body>
<div id='app'>
<img
        v-bind:src="picture"
        :alt="`${firstName} ${lastName}`"
        :class="gender"
      />
      <h1>{{firstName}} {{lastName}}</h1>
      <h3>Email: {{email}}</h3>
      <button :class="gender" @click="getUser()">Get Random User</button>
</div>  <div id="app">
      <img
        v-bind:src="picture"
        :alt="`${firstName} ${lastName}`"
        :class="gender"
      />
      <h1>{{firstName}} {{lastName}}</h1>
      <h3>Email: {{email}}</h3>
      <button :class="gender" @click="getUser()">Get Random User</button>
</div>

<script src="https://unpkg.com/vue@next"></script>
<script src="app.js"></script>
</body>
<footer>

</footer>
</html>